<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>album</title>
</head>

<style>
	table {
    border: 1px solid black;
}

td, th{
	border: 1px solid black;
}
#t{
	border: 1px solid black;
}
#t.td{
	border: 1px solid black;
}
</style>


<body>
<form method="post">
<table>

	<tr>
		<td>Albumname</td>
		<td><input type="text" name="albumname" /></td>
	</tr>
	<tr>
		<td>Singer</td>
		<td><input type="text" name="singer" /></td>
	</tr>
	<tr>
		<td>Year</td>
		<td><input type="text" name="year" /></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="submit" value="add" /></td>
	</tr>
</table>
<?php
if (isset($_POST['submit']))
	{	   
	include 'albumdb.php';
	
			 		$albumname=$_POST['albumname'] ;
					$singer= $_POST['singer'] ;					
					$year=$_POST['year'] ;
					
		$sql=	"INSERT INTO `album`(albumname,singer,year) 
		 VALUES ('$albumname','$singer','$year')";								
		$conn->query($sql); 
				
				
	        }
?>
</form>
<table id="t">
	
			<?php
			include("albumdb.php");
			
			$sql = "SELECT * FROM album";
			$result=$conn->query($sql);
			echo "<table>";
			while($test = mysqli_fetch_array($result))
			{
				$id = $test['albumID'];	
				echo "<tr align='center'>";	
				echo"<td><font color='black'>" .$test['albumID']."</font></td>";
				echo"<td><font color='black'>" .$test['albumname']."</font></td>";
				echo"<td><font color='black'>". $test['singer']. "</font></td>";
				echo"<td><font color='black'>". $test['year']. "</font></td>";
				echo"<td> <a href ='albumview.php?albumID=$id'>Edit</a>";
				echo"<td> <a href ='albumdel.php?albumID=$id'><center>Delete</center></a>";
									
				echo "</tr>";
			}
			echo "</table>";
			mysqli_close($conn);
			
			?>
			



</table>

</body>
</html>
