<?php
require("albumdb.php");
$id =$_REQUEST['albumID'];
$myq = "SELECT * FROM album WHERE albumID  = '$id'";
$result = $conn->query($myq);
$test = mysqli_fetch_array($result);
if (!$result) 
		{
		die("Error: Data not found..");
		}
				$albumname=$test['albumname'] ;
				$singer= $test['singer'] ;					
				$year=$test['year'] ;
				

if(isset($_POST['save']))
{	
	$albumname_save = $_POST['albumname'];
	$singer_save = $_POST['singer'];
	$year_save = $_POST['year'];
	

	$conn->query("UPDATE album SET albumname ='$albumname_save', singer ='$singer_save',
		 year ='$year_save' WHERE albumID = '$id'")
				or die(mysqli_error()); 
	echo "Saved!";
	
	header("Location: albumindex.php");			
}
mysqli_close($conn);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<form method="post">
<table>
	<tr>
		<td>Albumname:</td>
		<td><input type="text" name="albumname" value="<?php echo $albumname ?>"/></td>
	</tr>
	<tr>
		<td>Singer</td>
		<td><input type="text" name="singer" value="<?php echo $singer ?>"/></td>
	</tr>
	<tr>
		<td>Year</td>
		<td><input type="text" name="year" value="<?php echo $year ?>"/></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="save" value="save" /></td>
	</tr>
</table>

</body>
</html>
