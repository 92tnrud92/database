<?php  
	$conn = new mysqli('localhost', 'root', '','term');
	 if (!$conn)
    {
	 die('Could not connect: ' . mysqli_error());
	}
	
?>

