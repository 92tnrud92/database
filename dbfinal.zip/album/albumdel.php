<?php
  include("albumdb.php");  

	$id =$_REQUEST['albumID'];
	
	
	// sending query
	$conn->query("DELETE FROM album WHERE albumID = '$id'")
	or die(mysql_error());  	
	
	header("Location: albumindex.php");
?>
