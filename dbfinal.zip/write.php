<?php
	include("boarddb.php");


	echo "<form action=\"writesave.php\" method=\"post\">
	<input type=\"text\" name=\"title\" value=\"제목을 입력하시오\"><input type=\"text\" name=\"boardID\" value=\"boardID입력\"><br><br>
	<textarea name=\"posting\" rows=\"10\" cols=\"50\"></textarea><Br><br>
	<input type=\"submit\" value=\"write\">
	</form>"; 



?>