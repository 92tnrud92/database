<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>album</title>
</head>

<style>
	table {
    border: 1px solid black;
}

td, th{
	border: 1px solid black;
}
#t{
	border: 1px solid black;
}
#t.td{
	border: 1px solid black;
}
</style>


<body>	
			<?php
			include("songdb.php");
			session_start();

			$userid=$_SESSION['ses_ID'];



			echo "SONG : ablum natural join song";
			$sql = "SELECT * FROM album natural join song";
			$result=$conn->query($sql);
			
			echo "<table>";
			while($test = mysqli_fetch_array($result))
			{
				$songid = $test['songID'];	
				$songtitle = $test['songtitle'];	
				$albumid = $test['albumID'];
				$albumname = $test['albumname'];
				$singer = $test['singer'];
				$year = $test['year'];
				$genre = $test['genre'];
				echo "<tr align='center'>";	
				echo"<td>$albumid</td>";
				echo"<td>$singer</td>";
				echo"<td>$songtitle</td>";
				echo"<td>$genre</td>";
				
				echo "<form action=\"makeplaylist.php\" method=\"post\"><td><input type=\"text\" value=$songid name=\"songid\" readonly ><input type=\"submit\" value=\"insert_playlist\"></td>";
									
				echo "</tr>";
				echo "</form>";
			}
			echo "</table>";

			
			$sql2="SELECT * FROM playlist natural join song natural join user where ID=$userid";
			$result2=$conn->query($sql2);

			echo "<h2>$userid 's PLAYLIST</h2>";
			echo "<table>";
			while($test = mysqli_fetch_array($result2))
			{
				$songid = $test['songID'];	
				$albumid = $test['albumID'];
				echo "<tr align='center'>";	
				echo"<td><font color='black'>" .$test['singer']."</font></td>";
				echo"<td><font color='black'>". $test['songtitle']. "</font></td>";
				echo"<form action=\"deleteplaylist.php\" method=\"post\"><td><input type=\"text\" value=$songid name=\"songid\" readonly ><input type=\"submit\" value=\"delete_playlist\"></td></form>";
									
				echo "</tr>";
			}
			echo "</table>";






			mysqli_close($conn);
			echo"<a href =\"mainpage.php\">메인으로</a>";
			?>



</table>

</body>
</html>
