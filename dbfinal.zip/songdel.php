<?php
  include("albumdb.php");  

	$id =$_REQUEST['songID'];
	
	
	// sending query
	$conn->query("DELETE FROM song WHERE songID = '$id'")
	or die(mysql_error());  	
	
	header("Location: songindex.php");
?>
