<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>board</title>
</head>

<style>
	table {
    border: 1px solid black;
}

td, th{
	border: 1px solid black;
}
#t{
	border: 1px solid black;
}
#t.td{
	border: 1px solid black;
}
</style>


<body>
<form method="post">
<h2>오직 삭제만 가능</h2>
<?php
if (isset($_POST['submit']))
	{	   
	include 'boarddb.php';
	
			 		$boardname=$_POST['boardname'] ;
					
					
		$sql="INSERT INTO board(boardname) VALUES (\"$boardname\")";								
		$conn->query($sql); 
				
				
	        }
?>
</form>
<table id="t">
	
			<?php
			include("boarddb.php");
			
			$sql = "SELECT * FROM board natural join post";
			$result=$conn->query($sql);
			echo "<table>";
			while($test = mysqli_fetch_array($result))
			{
			
				$id = $test['postID'];	
				echo "<tr align='center'>";	
				echo"<td><font color='black'>" .$test['boardname']."</font></td>";
				echo"<td><font color='black'>" .$test['postID']."</font></td>";
				echo"<td><font color='black'>" .$test['title']."</font></td>";

				echo"<td> <a href ='postingdel.php?postID=$id'><center>Delete</center></a>";
									
				echo "</tr>";
			}
			echo "</table>";
			mysqli_close($conn);
			echo"<a href =\"mainpage.php\">메인으로</a>";

			
			?>
</table>

</body>
</html>
