<?php
 session_cache_limiter("private_no_expire");
 session_start();      
?>
