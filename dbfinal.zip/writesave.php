<?php
	include("boarddb.php");

	session_start();

	$userid=$_SESSION['ses_ID'];
	$postingtitle=$_POST['title'];
	$contents = $_POST['posting'];
	$boardID = $_POST['boardID'];
	$date = date('Y m d');

	$sql = "insert into post(title, content, date, hit, ID, boardID) values(\"$postingtitle\", \"$contents\", \"$date\", 0, $userid, $boardID)";

	
	$result=$conn->query($sql);

	header("Location: userboard.php");	



?>