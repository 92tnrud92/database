
<?php



$p_no = $_REQUEST['bno'];

include("userboarddb.php");
      
      session_start();
      
      $userid=$_SESSION['ses_ID'];
      



      $sql = "SELECT * FROM board natural join post where postID=$p_no";
      $result=$conn->query($sql);
     
      echo "<table border='1'>";
      while($test = mysqli_fetch_array($result))
      {
        $id = $test['boardID']; 
        echo "<tr align='center'>"; 
        echo"<td><font color='black'>" .$test['ID']."</font></td>";
        echo"<td><font color='black'>" .$test['title']."</font></td>";
        echo"<td><font color='black'>" .$test['date']."</font></td></tr>";  

        echo"<tr><td colspan='3'><font color='black'>" .$test['content']."</font></td></tr>";
                        
          }
     
      echo "</table><br><br><br>";





      $sql2 = "SELECT * FROM reply where postID=$p_no";
      $result2=$conn->query($sql2);




      echo "<table border='1'>";
       while($test = mysqli_fetch_array($result2))
      {
        $id = $test['ID']; 
        echo "<tr align='center'>"; 
        echo"<td><font color='black'>" .$test['ID']."</font></td>";
        echo"<td><font color='black'>" .$test['reply']."</font></td>";
                        
        echo "</tr>";
      }
     
      echo "</table>";




      mysqli_close($conn);

      echo "<br>";
      echo "<form action=\"replysaver.php?postID=$p_no&userid=$userid\" method=\"post\">
		<input type=\"text\" size=\"50\"name=\"reply\">
		<input type=\"submit\" value=\"댓글\">


      </form>";

      echo"<a href =\"mainpage.php\">메인으로</a>";











?>

