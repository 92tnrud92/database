<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>album</title>
</head>

<style>
	table {
    border: 1px solid black;
}

td, th{
	border: 1px solid black;
}
#t{
	border: 1px solid black;
}
#t.td{
	border: 1px solid black;
}
</style>


<body>

	
			<?php
			include("albumdb.php");
			session_start();
			$userid=$_SESSION['ses_ID'];
			
			$sql = "SELECT * FROM album";

			$result=$conn->query($sql);

			echo "<table><tr><th>앨범id</th>
			<th>앨범제목</th>
			<th>가수</th>
			
			<th>리뷰 & 평점</th>
			
			</tr>";


			while($test = mysqli_fetch_array($result))
			{
				$id = $test['albumID'];
				$albumname = $test['albumname'];
				$_SESSION['ses_albumID']=$id;
				$count;//앨범아이디가 id인 거 갯수세고. 나누기해주면 돼. avg 쿼리 처리
				
				echo "<tr align='center'>";	
				echo"<td><font color='black'>" .$id."</font></td>";
				echo"<td><font color='black'>" .$test['albumname']."</font></td>";
				echo"<td><font color='black'>". $test['singer']. "</font></td>";
				echo"<form action=\"albumreviewinsert.php\" method=\"post\"><td><input type=\"text\" value=$id name=\"albumID\" readonly><br><input type=\"text\" value=\"리뷰\" name=\"review\" ><br>
				<input type=\"text\"value=\"평점\" name=\"score\" ><br><input type=\"submit\" value=\"insert\"></td></form>";
				
				
				echo "</tr>";
			}
			echo "</table>";
			mysqli_close($conn);



			
			?>
			


		<?php

			include("albumdb.php");			
		
			echo "<h1>평점</h1>";

			$sql = "SELECT* FROM album natural join review";
			$conn2 = $conn;
			$result=$conn->query($sql);

			echo "<table><tr><th>앨범id</th>
			<th>앨범제목</th>
			<th>가수</th>
			<th>평점</th></tr>";



			while($test = mysqli_fetch_array($result))
			{
				$id = $test['albumID'];				
				$_SESSION['ses_albumID']=$id;
				$avg= "SELECT AVG(score) FROM album natural join review where albumID=$id";
				$result2 = $conn2->query($avg);
				$test2 = mysqli_fetch_array($result2);
				$sss = $test2['AVG(score)'];

				echo "<tr align='center'>";	
				echo"<td><font color='black'>" .$test['albumID']."</font></td>";
				echo"<td><font color='black'>" .$test['albumname']."</font></td>";
				echo"<td><font color='black'>" .$test['singer']."</font></td>";
				echo"<td><font color='black'>". $test2['AVG(score)']. "</font></td>";	
				
				echo "</tr>";
			}
			echo "</table>";
			mysqli_close($conn);

			


			?>
	

		<?php
			include("albumdb.php");
			
		
			echo "<h1>모든 리뷰</h1>";
			$sql = "SELECT * FROM album natural join review";

			$result=$conn->query($sql);

			echo "<table><tr><th>앨범id</th>
			<th>앨범제목</th>
			<th>가수</th>
			<th>평점</th>
			<th>ID</th>
			<th>리뷰</th>
			
			</tr>";


			while($test = mysqli_fetch_array($result))
			{
				$id = $test['albumID'];
				$albumname = $test['albumname'];
				$_SESSION['ses_albumID']=$id;
				
				
				echo "<tr align='center'>";	
				echo"<td><font color='black'>" .$test['albumID']."</font></td>";
				echo"<td><font color='black'>" .$test['albumname']."</font></td>";
				echo"<td><font color='black'>". $test['singer']. "</font></td>";
				echo"<td><font color='black'>". $test['score']. "</font></td>";
				echo"<td><font color='black'>". $test['ID']. "</font></td>";
				echo"<td><font color='black'>". $test['review']. "</font></td>";
				
				
				echo "</tr>";
			}
			echo "</table>";
			mysqli_close($conn);


			echo"<a href =\"mainpage.php\">메인으로</a>";
			?>
			

</body>
</html>
