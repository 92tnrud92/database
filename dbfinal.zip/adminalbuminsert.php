<doctype html>
<html>
<head>
<meta charset="utf-8">
<title>sign up page</title>
</head>
<body>
<form name="join" method="post" action="albumsaver.php"> <!--membersave.php 파일로 회원정보저장-->
 <h1>input album information</h1>
 <table border="1">
  <tr>
   <td>Albumname</td>
   <td><input type="text" size="30" name="albumname"></td>
  </tr>
  <tr>
   <td>Singer</td>
   <td><input type="text" size="30" maxlength="30" name="singer"></td>
  </tr>
  <tr>
   <td>year</td>
   <td><input type="text" size="30" name="year"></td>
  </tr>
  
 </table>
 
 <input type=submit value="insert"><input type=reset value="rewrite">
 
   <input type="button" value="뒤로가기"onclick="javascripｔ:history.go(-1)">
</form>
</body>
</html>
