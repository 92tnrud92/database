<?php
  include("boarddb.php");  

	$id =$_REQUEST['boardID'];
	
	
	// sending query
	$conn->query("DELETE FROM board WHERE boardID = '$id'")
	or die(mysql_error());  	
	
	header("Location: boardindex.php");
?>
