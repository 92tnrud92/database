<?php
require("boarddb.php");
$id =$_REQUEST['boardID'];
$myq = "SELECT * FROM board WHERE boardID  = '$id'";
$result = $conn->query($myq);
$test = mysqli_fetch_array($result);
if (!$result) 
		{
		die("Error: Data not found..");
		}
				$boardname=$test['boardname'] ;
				

if(isset($_POST['save']))
{	
	$boardname_save = $_POST['boardname'];
	

	$conn->query("UPDATE board SET boardname ='$boardname_save' WHERE boardID = '$id'")
				or die(mysqli_error()); 
	echo "Saved!";
	
	header("Location: boardindex.php");			
}
mysqli_close($conn);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<form method="post">
<table>
	<tr>
		<td>Board:</td>
		<td><input type="text" name="boardname" value="<?php echo $boardname ?>"/></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="save" value="save" /></td>
	</tr>
</table>

</body>
</html>
