    <?
    include"session.php";   //session.php파일을 포함

    ?>
 
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <title>DB</title>
 <style>
   table, th, tr, td{
    border: 1px black;
   }


 </style>
<body>

<h1>BOARD</h1>
   <?php
      include("userboarddb.php");
      
      $sql = "SELECT * FROM board";
      $result=$conn->query($sql);
      echo "<table>";
      echo "<form method=\"post\">";

      while($test = mysqli_fetch_array($result))
      {
        $id = $test['boardID']; 
        echo "<tr align='center'>"; 
        echo"<td><input type='submit' name='$id' value='$id'><font color='black'>" .$test['boardID']."</font></button></td>";
        echo"<td><font color='black'>" .$test['boardname']."</font></td>";
                        
        echo "</tr>";
      }
      echo "</form>";
      echo "</table>";
      mysqli_close($conn);
      echo "<br>";
      echo "<br>";
      echo "<br>";
      

      
      ?>

      <form action="write.php" method="post">
      <input type="submit" value="글쓰기" name="write">
      </form>

      <div class="searchBox">
        <form action="./index.php" method="get">
          <select name="searchColumn">
            <option <?php echo $searchColumn=='b_title'?'selected="selected"':null?> value="b_title">제목</option>
            <option <?php echo $searchColumn=='b_content'?'selected="selected"':null?> value="b_content">내용</option>
            <option <?php echo $searchColumn=='b_id'?'selected="selected"':null?> value="b_id">작성자</option>
          </select>
          <input type="text" name="searchText" value="<?php echo isset($searchText)?$searchText:null?>">
          <button type="submit">검색</button>
        </form>
      </div>



   <?php
    if(isset($_POST['1']))
    {
      include("userboarddb.php");
      
      $sql = "SELECT * FROM post natural join board where boardID=1";
      $result=$conn->query($sql);
      
      echo "<table>";
      echo "<article>
    
    <table>
     
      <thead>
        <tr>
          <th scope=\"col\" class=\"no\">번호</th>
          <th scope=\"col\" class=\"title\">제목</th>
          <th scope=\"col\" class=\"author\">작성자</th>
          <th scope=\"col\" class=\"date\">작성일</th>
          <th scope=\"col\" class=\"hit\">조회</th>
        </tr>
      </thead>
      <tbody>
      </tbody>
  
  ";


      while($test = mysqli_fetch_array($result))
      {
        $id = $test['postID']; 
        $title = $test['title'];
        echo "<tr align='center'>"; 
        echo"<td><font color='black'>" .$test['postID']."</font></button></td>";
        echo "<td>";
        echo "<a href=\"./view.php?bno=$id\">";
        echo "$title</a></td>";
        echo"<td><font color='black'>" .$test['ID']."</font></button></td>";
        echo"<td><font color='black'>" .$test['date']."</font></button></td>";
         echo"<td><font color='black'>" .$test['hit']."</font></button></td>";                           
        echo "</tr>";
      }
     
      echo "</table></article>";
      mysqli_close($conn);
      
    }




   ?>
       

 
 
    
  </body>
</html>
