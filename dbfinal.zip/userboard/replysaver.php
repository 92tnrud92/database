    <?
    include"session.php";   //session.php파일을 포함

    ?>

<html>
   <meta charset="utf-8">
<?php
 
$host = 'localhost';
$user = 'root';
$pw = '';
$dbName = 'term';
$mysqli = new mysqli($host, $user, $pw,$dbName);
 
 $id=$_SESSION['ID'];
 $postID=$_REQUEST['postID'];
 $reply=$_POST['reply'];
 
 
 $sql = "insert into reply (postID, ID, reply)";             // (입력받음)insert into 테이블명 (column-list)
 $sql = $sql. "values('$postID','$id','$reply')";         // calues(column-list에 넣을 value-list)
 if($mysqli->query($sql)){                                                              //만약 sql로 잘 들어갔으면
  echo 'success inserting <p/>';                                                            //success inserting 으로 표시
                                   // id님 안녕하세요.
 }else{                                                                                //아니면
  echo 'fail to insert sql';                                                            //fail to insert sql로 표시
 }
mysqli_close($mysqli);
 
 header("Location: view.php?bno=$postID");		
?>
</html>
