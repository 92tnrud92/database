    <?
    include"session.php";   //session.php파일을 포함

    ?>


<?php



$p_no = $_REQUEST['bno'];

include("userboarddb.php");
      
      $sql = "SELECT * FROM board natural join post where postID=$p_no";
      $result=$conn->query($sql);
     
      echo "<table border='1'>";
      while($test = mysqli_fetch_array($result))
      {
        $id = $test['boardID']; 
        echo "<tr align='center'>"; 
        echo"<td><font color='black'>" .$test['content']."</font></td>";
                        
        echo "</tr>";
      }
     
      echo "</table><br><br><br>";





      $sql2 = "SELECT * FROM reply natural join post where postID=$p_no";
      $result2=$conn->query($sql2);




      echo "<table border='1'>";
       while($test = mysqli_fetch_array($result2))
      {
        $id = $test['ID']; 
        echo "<tr align='center'>"; 
        echo"<td><font color='black'>" .$test['ID']."</font></td>";
        echo"<td><font color='black'>" .$test['reply']."</font></td>";
                        
        echo "</tr>";
      }
     
      echo "</table>";




      mysqli_close($conn);

      echo "<br>";
      echo "<form action=\"replysaver.php?postID=$p_no\" method=\"post\">
		<input type=\"text\" size=\"100\"name=\"reply\">
		<input type=\"submit\" value=\"댓글\">

      </form>";










?>