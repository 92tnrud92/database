<html>
   <meta charset="utf-8">
<?php
 
$host = 'localhost';
$user = 'root';
$pw = '';
$dbName = 'term';
$mysqli = new mysqli($host, $user, $pw,$dbName);
 

 $albumname=($_POST['albumname']);
 $singer=$_POST['singer'];
 $year=$_POST['year'];
 
 
 $sql = "insert into album(albumname, singer, year)";             // (입력받음)insert into 테이블명 (column-list)
 $sql = $sql. "values('$albumname','$singer','$year')";         // calues(column-list에 넣을 value-list)
 if($mysqli->query($sql)){                                                              //만약 sql로 잘 들어갔으면
  echo 'success inserting <p/>';                                                            //success inserting 으로 표시
                                     
 }else{                                                                                //아니면
  echo 'fail to insert sql';                                                            //fail to insert sql로 표시
 }
mysqli_close($mysqli);
 
 
?>
<input type="button" value="메인으로" onclick="location='login.php'">
</html>
