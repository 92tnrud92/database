<?php


			include("songdb.php");
			session_start();

			$userid=$_SESSION['ses_ID'];
			$songId=$_POST['songid'];

			$sql = "delete from playlist where ID=$userid and songID= $songId";


			$result=$conn->query($sql);

			header("Location: playlist.php");	
			


?>