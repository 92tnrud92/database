<?php


			include("songdb.php");
			session_start();

			$userid=$_SESSION['ses_ID'];
			$albumid=$_POST['albumID'];
			$review=$_POST['review'];
			$score=$_POST['score'];

			$sql = "insert into review values ($albumid, $userid, $score,\"$review\")";

			$result=$conn->query($sql);

			echo $sql;

			header("Location: albumreview.php");	
			



?>