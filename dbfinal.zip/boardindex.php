<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>board</title>
</head>

<style>
	table {
    border: 1px solid black;
}

td, th{
	border: 1px solid black;
}
#t{
	border: 1px solid black;
}
#t.td{
	border: 1px solid black;
}
</style>


<body>
<form method="post">
<table>

	<tr>
		<td>Boardname</td>
		<td><input type="text" name="boardname" /></td>
	</tr>
	
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="submit" value="add" /></td>
	</tr>
</table>
<?php
if (isset($_POST['submit']))
	{	   
	include 'boarddb.php';
	
			 		$boardname=$_POST['boardname'] ;
					
					
		$sql="INSERT INTO board(boardname) VALUES (\"$boardname\")";								
		$conn->query($sql); 
				
				
	        }
?>
</form>
<table id="t">
	
			<?php
			include("boarddb.php");
			
			$sql = "SELECT * FROM board";
			$result=$conn->query($sql);
			echo "<table>";
			while($test = mysqli_fetch_array($result))
			{
				$id = $test['boardID'];	
				echo "<tr align='center'>";	
				echo"<td><font color='black'>" .$test['boardID']."</font></td>";
				echo"<td><font color='black'>" .$test['boardname']."</font></td>";
				echo"<td> <a href ='boardview.php?boardID=$id'>Edit</a>";
				echo"<td> <a href ='boarddel.php?boardID=$id'><center>Delete</center></a>";
									
				echo "</tr>";
			}
			echo "</table>";
			mysqli_close($conn);
			echo"<a href =\"mainpage.php\">메인으로</a>";

			
			?>
</table>

</body>
</html>
