<?php
  include("boarddb.php");  

	$id =$_REQUEST['postID'];
	
	
	// sending query
	$conn->query("DELETE FROM post WHERE postID = '$id'")
	or die(mysql_error());  	
	
	header("Location: postingindex.php");
?>
