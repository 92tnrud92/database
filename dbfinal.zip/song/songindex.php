<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>album</title>
</head>

<style>
	table {
    border: 1px solid black;
}

td, th{
	border: 1px solid black;
}
#t{
	border: 1px solid black;
}
#t.td{
	border: 1px solid black;
}
</style>


<body>
<form method="post">
<table>

	<tr>
		<td>AlbumID</td>
		<td><input type="text" name="albumID" /></td>
	</tr>
	<tr>
		<td>songtitle</td>
		<td><input type="text" name="songtitle" /></td>
	</tr>
	<tr>
		<td>singer</td>
		<td><input type="text" name="singer" /></td>
	</tr>
	<tr>
		<td>genre</td>
		<td><input type="text" name="genre" /></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="submit" value="add" /></td>
	</tr>
</table>
<?php
if (isset($_POST['submit']))
	{	   
	include 'songdb.php';
	
			 		$albumID=$_POST['albumID'] ;
					$singer= $_POST['singer'] ;					
					$songtitle=$_POST['songtitle'] ;
					$genre= $_POST['genre'] ;
					

		$sql=	"INSERT INTO `song`(albumID,songtitle,singer,genre) 
		 VALUES ('$albumID','$songtitle','$singer','$genre')";								
		$conn->query($sql); 
				
				
	        }
?>
</form>
<table id="t">
			<?php
			include("songdb.php");
			echo "ABLUM";
			$sql = "SELECT * FROM album";
			$result=$conn->query($sql);
			echo "<table>";
			while($test = mysqli_fetch_array($result))
			{
				$id = $test['albumID'];	
				echo "<tr align='center'>";	
				echo"<td><font color='black'>" .$test['albumID']."</font></td>";
				echo"<td><font color='black'>" .$test['albumname']."</font></td>";
				echo"<td><font color='black'>". $test['singer']. "</font></td>";
				echo"<td><font color='black'>". $test['year']. "</font></td>";
									
				echo "</tr>";
			}
			echo "</table>";
			mysqli_close($conn);
			
			?>
	
			<?php
			include("songdb.php");
			echo "SONG : ablum natural join song";
			$sql = "SELECT * FROM album natural join song";
			$result=$conn->query($sql);
			echo "<table>";
			while($test = mysqli_fetch_array($result))
			{
				$songid = $test['songID'];	
				$albumid = $test['albumID'];
				echo "<tr align='center'>";	
				echo"<td><font color='black'>" .$test['albumID']."</font></td>";
				echo"<td><font color='black'>" .$test['albumname']."</font></td>";
				echo"<td><font color='black'>" .$test['singer']."</font></td>";
				echo"<td><font color='black'>". $test['year']. "</font></td>";
				echo"<td><font color='black'>". $test['songID']. "</font></td>";
				echo"<td><font color='black'>". $test['songtitle']. "</font></td>";
				echo"<td><font color='black'>". $test['genre']. "</font></td>";
				echo"<td> <a href ='songview.php?songID=$songid &albumID=$albumid'>Edit</a>";
				echo"<td> <a href ='songdel.php?songID=$songid'><center>Delete</center></a>";
									
				echo "</tr>";
			}
			echo "</table>";
			mysqli_close($conn);
			
			?>



</table>

</body>
</html>
