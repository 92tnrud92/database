<?php
require("songdb.php");
$songid =$_REQUEST['songID'];
$albumid =$_REQUEST['albumID'];

$myq = "SELECT * FROM album natural join song WHERE songID  = '$songid' and albumID ='$albumid'";
$result = $conn->query($myq);
$test = mysqli_fetch_array($result);
if (!$result) 
		{
		die("Error: Data not found..");
		}
					$songID=$test['songID'] ;
					$albumname=$test['albumname'];
					$singer= $test['singer'] ;					
					$songtitle=$test['songtitle'] ;
					$genre= $test['genre'] ;
					$year = $test['year'];
									

if(isset($_POST['save']))
{	
	$albumname_save = $_POST['albumname'];
	$singer_save = $_POST['singer'];
	//$year_save = $_POST['year'];
	$songtitle_save = $_POST['songtitle'];
	$genre_save = $_POST['genre'];
	

	$conn->query("UPDATE album natural join song SET albumID ='$albumid', singer ='$singer_save',
		 year ='$year', songtitle='$songtitle_save', genre='$genre_save' WHERE songID  = '$songid' and albumID = '$albumid'")
				or die(mysqli_error()); 
	echo "Saved!";
	
	header("Location: songindex.php");			
}
mysqli_close($conn);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<form method="post">
<table>
	<tr>
		<td>Albumname:</td>
		<td><input type="text" name="albumname" value="<?php echo $albumname ?>"/></td>
	</tr>
	<tr>
		<td>Singer</td>
		<td><input type="text" name="singer" value="<?php echo $singer ?>"/></td>
	</tr>
	<tr>
		<td>songtitle</td>
		<td><input type="text" name="songtitle" value="<?php echo $songtitle ?>"/></td>
	</tr>
	<tr>
		<td>genre</td>
		<td><input type="text" name="genre" value="<?php echo $genre ?>"/></td>
	</tr>

	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="save" value="save" /></td>
	</tr>
</table>

</body>
</html>
