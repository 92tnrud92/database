<html>
   <meta charset="utf-8">
<?php
 
$host = 'localhost';
$user = 'root';
$pw = '';
$dbName = 'term';
$mysqli = new mysqli($host, $user, $pw,$dbName);
 
 $id=$_POST['id'];
 $password=($_POST['pwd']);
 $nickname=$_POST['name'];
 $email=$_POST['email'];
 $address=$_POST['address'];
 $phonenum=$_POST['phonenum'];
 
 
 $sql = "insert into user (ID, password, nickname, email, address, phonenum)";             // (입력받음)insert into 테이블명 (column-list)
 $sql = $sql. "values('$id','$password','$nickname','$email','$address','$phonenum')";         // calues(column-list에 넣을 value-list)
 if($mysqli->query($sql)){                                                              //만약 sql로 잘 들어갔으면
  echo 'success inserting <p/>';                                                            //success inserting 으로 표시
  echo $nickname.'님 가입 되셨습니다.<p/>';                                   // id님 안녕하세요.
 }else{                                                                                //아니면
  echo 'fail to insert sql';                                                            //fail to insert sql로 표시
 }
mysqli_close($mysqli);
 
 
?>
<input type="button" value="로그인하러가기" onclick="location='index.php'">
</html>
