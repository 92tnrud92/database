<?php


			include("songdb.php");
			session_start();

			$userid=$_SESSION['ses_ID'];
			$songId=$_POST['songid'];

			$sql = "insert into playlist values ($userid, $songId)";
			$result=$conn->query($sql);

			header("Location: playlist.php");	
			



?>